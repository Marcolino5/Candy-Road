.mif do data e text do ligue-4 estão como padrão em RISCV-v23_restored, mas também as
deixamos na pasta Ligue4