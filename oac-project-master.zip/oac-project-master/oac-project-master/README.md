# oac-project
Pokemon in RISC-V Assembly.